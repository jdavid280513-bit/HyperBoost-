package com.hyperboost.app

import android.Manifest
import android.app.*
import android.app.usage.UsageStats
import android.app.usage.UsageStatsManager
import android.content.*
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.net.Uri
import android.os.*
import android.provider.Settings
import java.io.File

fun fmt(b: Long): String {
    val u = arrayOf("B", "KB", "MB", "GB", "TB"); var v = b.toDouble(); var i = 0
    while (v >= 1024 && i < 4) { v /= 1024; i++ }
    return "%.1f %s".format(v, u[i])
}
fun ago(ms: Long): String = if (ms <= 0) "sin registros" else "hace ${(System.currentTimeMillis() - ms) / 86400000} días"

fun Context.battery(): Triple<Int, Float, Boolean> {
    val i = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
    val l = i?.getIntExtra("level", 0) ?: 0; val s = i?.getIntExtra("scale", 100) ?: 100
    val t = i?.getIntExtra("temperature", -1) ?: -1
    val st = i?.getIntExtra("status", 0) ?: 0
    return Triple(l * 100 / s, if (t > 0) t / 10f else -1f, st == BatteryManager.BATTERY_STATUS_CHARGING)
}
fun Context.ram(): Pair<Long, Long> {
    val mi = ActivityManager.MemoryInfo(); getSystemService(ActivityManager::class.java).getMemoryInfo(mi)
    return (mi.totalMem - mi.availMem) to mi.totalMem
}
fun storage(): Pair<Long, Long> {
    val s = StatFs(Environment.getDataDirectory().path); val t = s.totalBytes
    return (t - s.availableBytes) to t
}

// ---- permisos ----
fun Context.has(p: String) = checkSelfPermission(p) == PackageManager.PERMISSION_GRANTED
fun Context.hasNotif() = Build.VERSION.SDK_INT < 33 || has(Manifest.permission.POST_NOTIFICATIONS)
fun Context.hasPhotos() = if (Build.VERSION.SDK_INT >= 33) has(Manifest.permission.READ_MEDIA_IMAGES) else has(Manifest.permission.READ_EXTERNAL_STORAGE)
fun hasAllFiles() = Environment.isExternalStorageManager()
fun Context.hasUsage(): Boolean =
    getSystemService(AppOpsManager::class.java).unsafeCheckOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), packageName) == AppOpsManager.MODE_ALLOWED
fun Context.hasDnd() = getSystemService(NotificationManager::class.java).isNotificationPolicyAccessGranted

fun Context.open(i: Intent) {
    try { startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
    catch (e: Exception) { startActivity(Intent(Settings.ACTION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
}
fun Context.allFilesIntent() = Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:$packageName"))
fun Context.usageIntent() = Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)
fun Context.appDetails(pkg: String) = open(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$pkg")))

fun Context.notify(title: String, text: String) {
    if (!hasNotif()) return
    val nm = getSystemService(NotificationManager::class.java)
    nm.createNotificationChannel(NotificationChannel("hb", "HyperBoost", NotificationManager.IMPORTANCE_DEFAULT))
    nm.notify(1, Notification.Builder(this, "hb").setSmallIcon(android.R.drawable.stat_sys_download_done)
        .setContentTitle(title).setContentText(text).build())
}

// ---- apps ----
data class AppI(val pkg: String, val label: String, val system: Boolean, val enabled: Boolean, val installed: Long, val game: Boolean)

@Suppress("DEPRECATION")
fun Context.apps(): List<AppI> = packageManager.getInstalledApplications(0).filter { it.packageName != packageName }.map {
    val sys = (it.flags and ApplicationInfo.FLAG_SYSTEM) != 0 && (it.flags and ApplicationInfo.FLAG_UPDATED_SYSTEM_APP) == 0
    val inst = runCatching { packageManager.getPackageInfo(it.packageName, 0).firstInstallTime }.getOrDefault(0L)
    AppI(it.packageName, packageManager.getApplicationLabel(it).toString(), sys, it.enabled, inst,
        it.category == ApplicationInfo.CATEGORY_GAME || (it.flags and ApplicationInfo.FLAG_IS_GAME) != 0)
}
fun Context.launchable() = apps().filter { !it.system && it.enabled && packageManager.getLaunchIntentForPackage(it.pkg) != null }
    .sortedBy { it.label.lowercase() }

fun Context.usage(days: Int = 1): Map<String, UsageStats> {
    if (!hasUsage()) return emptyMap()
    val e = System.currentTimeMillis()
    return getSystemService(UsageStatsManager::class.java).queryAndAggregateUsageStats(e - days * 86400000L, e)
}
fun Context.killBg(pkgs: List<String> = launchable().map { it.pkg }): Int {
    val am = getSystemService(ActivityManager::class.java)
    pkgs.filter { it != packageName }.forEach { am.killBackgroundProcesses(it) }
    return pkgs.size
}

// ---- limpiador ----
data class Junk(val file: File, val size: Long, val kind: String)

fun scanJunk(ctx: Context): List<Junk> {
    val out = ArrayList<Junk>()
    fun kind(f: File): String? {
        val n = f.name.lowercase(); val p = f.path
        return when {
            "/.thumbnails/" in p || n.startsWith(".thumbdata") -> "Miniaturas"
            n.endsWith(".tmp") || n.endsWith(".temp") || n.endsWith(".chck") -> "Temporal"
            n.endsWith(".log") || n.endsWith(".bak") || n.endsWith(".old") -> "Posible basura"
            n.endsWith(".apk") && "/Download" in p -> "APK descargado"
            f.length() == 0L && n != ".nomedia" -> "Archivo vacío"
            else -> null
        }
    }
    listOfNotNull(ctx.cacheDir, ctx.externalCacheDir).forEach { d ->
        d.walkTopDown().filter { it.isFile }.forEach { out += Junk(it, it.length(), "Caché de HyperBoost") }
    }
    if (hasAllFiles()) {
        val root = Environment.getExternalStorageDirectory()
        root.walkTopDown().onEnter { !(it.name == "Android" && it.parentFile == root) }
            .filter { it.isFile }.forEach { f -> if (out.size < 3000) kind(f)?.let { out += Junk(f, f.length(), it) } }
    }
    return out.sortedByDescending { it.size }
}
