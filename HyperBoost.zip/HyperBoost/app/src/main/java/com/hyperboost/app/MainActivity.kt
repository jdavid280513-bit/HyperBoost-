package com.hyperboost.app

import android.Manifest
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

val Blue = Color(0xFF2979FF)
val Cyan = Color(0xFF22D3EE)
val CardBg = Color(0xFF111418)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(primary = Blue, secondary = Cyan, background = Color.Black,
                surface = CardBg, onBackground = Color.White, onSurface = Color.White, onPrimary = Color.White)) { App() }
        }
    }
}

@Composable fun Cardx(mod: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) =
    Card(mod.fillMaxWidth(), shape = RoundedCornerShape(20.dp), colors = CardDefaults.cardColors(containerColor = CardBg)) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp), content = content)
    }
@Composable fun BigBtn(text: String, onClick: () -> Unit) =
    Button(onClick, Modifier.fillMaxWidth().height(56.dp), shape = RoundedCornerShape(16.dp)) { Text(text, fontWeight = FontWeight.Bold) }
@Composable fun Title(t: String) = Text(t, fontSize = 24.sp, fontWeight = FontWeight.Bold)
@Composable fun Dim(t: String) = Text(t, color = Color.Gray, fontSize = 13.sp)

@Composable fun Ring(p: Float, big: String, small: String) {
    val a by animateFloatAsState(p.coerceIn(0f, 1f), tween(900), label = "ring")
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Box(Modifier.size(84.dp), contentAlignment = Alignment.Center) {
            Canvas(Modifier.fillMaxSize().padding(8.dp)) {
                val s = Stroke(10.dp.toPx(), cap = StrokeCap.Round)
                drawArc(Color(0xFF1E2530), 0f, 360f, false, style = s)
                drawArc(Brush.sweepGradient(listOf(Cyan, Blue, Cyan)), -90f, 360f * a, false, style = s)
            }
            Text(big, fontWeight = FontWeight.Bold)
        }
        Dim(small)
    }
}

@Composable fun App() {
    val ctx = LocalContext.current
    var tab by remember { mutableIntStateOf(0) }
    var sub by remember { mutableStateOf<String?>(null) }
    var tick by remember { mutableIntStateOf(0) }
    val lo = LocalLifecycleOwner.current
    DisposableEffect(lo) {
        val o = LifecycleEventObserver { _, e -> if (e == Lifecycle.Event.ON_RESUME) tick++ }
        lo.lifecycle.addObserver(o); onDispose { lo.lifecycle.removeObserver(o) }
    }
    val perm = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { tick++ }
    LaunchedEffect(Unit) {
        perm.launch(arrayOf(Manifest.permission.POST_NOTIFICATIONS, Manifest.permission.READ_MEDIA_IMAGES, Manifest.permission.READ_EXTERNAL_STORAGE))
    }
    BackHandler(sub != null) { sub = null }
    val tabs = listOf("INICIO" to Icons.Filled.Home, "LIMPIADOR" to Icons.Filled.Delete, "RENDIMIENTO" to Icons.Filled.Build,
        "SEGURIDAD" to Icons.Filled.Lock, "HERRAMIENTAS" to Icons.Filled.Menu)
    Scaffold(containerColor = Color.Black, bottomBar = {
        NavigationBar(containerColor = Color(0xFF0A0C10)) {
            tabs.forEachIndexed { i, (n, ic) ->
                NavigationBarItem(selected = tab == i && sub == null, onClick = { tab = i; sub = null },
                    icon = { Icon(ic, n) }, label = { Text(n, fontSize = 8.sp, maxLines = 1) },
                    colors = NavigationBarItemDefaults.colors(selectedIconColor = Color.White, indicatorColor = Blue, selectedTextColor = Cyan))
            }
        }
    }) { pad ->
        Box(Modifier.padding(pad).fillMaxSize()) {
            key(tick) {
                when (sub) {
                    "freezer" -> Freezer(); "photos" -> Photos(); "game" -> Game(); "info" -> Info(); "settings" -> SettingsScreen()
                    else -> when (tab) {
                        0 -> Home({ sub = it }, { perm.launch(arrayOf(Manifest.permission.POST_NOTIFICATIONS, Manifest.permission.READ_MEDIA_IMAGES, Manifest.permission.READ_EXTERNAL_STORAGE)) })
                        1 -> Cleaner(); 2 -> Perf(); 3 -> Security(); else -> Tools { sub = it }
                    }
                }
            }
        }
    }
}

@Composable fun Home(openSub: (String) -> Unit, askPerm: () -> Unit) {
    val ctx = LocalContext.current; val scope = rememberCoroutineScope()
    val (bat, temp, chg) = remember { ctx.battery() }
    val (ru, rt) = remember { ctx.ram() }; val (su, st) = remember { storage() }
    var msg by remember { mutableStateOf("") }; var busy by remember { mutableStateOf(false) }
    val notes = buildList {
        if (ru * 100 / rt > 85) add("RAM alta")
        if (su * 100 / st > 90) add("Almacenamiento casi lleno")
        if (bat < 15 && !chg) add("Batería baja")
        if (temp > 42) add("Batería caliente")
    }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Image(painterResource(R.drawable.logo), null, Modifier.size(56.dp).clip(RoundedCornerShape(14.dp)))
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) { Text("HyperBoost", fontSize = 26.sp, fontWeight = FontWeight.Bold); Dim("Libera tu potencia. Lleva tu teléfono al máximo.") }
            IconButton({ openSub("settings") }) { Icon(Icons.Filled.Settings, "Ajustes") }
        }
        Cardx {
            Row(Modifier.fillMaxWidth(), Arrangement.SpaceEvenly) {
                Ring(bat / 100f, "$bat%", if (chg) "Cargando" else "Batería")
                Ring(ru.toFloat() / rt, "${ru * 100 / rt}%", "RAM")
                Ring(su.toFloat() / st, "${su * 100 / st}%", "Almacenamiento")
            }
        }
        Cardx {
            Text("Estado general", fontWeight = FontWeight.Bold)
            Text(if (notes.isEmpty()) "Todo en orden" else notes.joinToString(" · "), color = if (notes.isEmpty()) Cyan else Color(0xFFFFB74D))
            Dim("RAM ${fmt(ru)} / ${fmt(rt)} · Almacenamiento ${fmt(su)} / ${fmt(st)}")
            Dim(if (temp > 0) "Temperatura de batería: $temp °C" else "Temperatura de batería: no disponible")
        }
        Cardx {
            Text("Permisos", fontWeight = FontWeight.Bold)
            PermRow("Notificaciones", ctx.hasNotif()) { askPerm() }
            PermRow("Administrar todo el almacenamiento (limpieza)", hasAllFiles()) { ctx.open(ctx.allFilesIntent()) }
            PermRow("Acceso a fotos (duplicadas)", ctx.hasPhotos()) { askPerm() }
            PermRow("Acceso de uso de apps (rendimiento / freezer)", ctx.hasUsage()) { ctx.open(ctx.usageIntent()) }
            PermRow("No molestar (Game Boost)", ctx.hasDnd()) { ctx.open(Intent(android.provider.Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS)) }
        }
        BigBtn(if (busy) "OPTIMIZANDO…" else "OPTIMIZAR AHORA") {
            if (busy) return@BigBtn
            scope.launch {
                busy = true
                val before = ctx.ram().let { it.second - it.first }
                val n = ctx.killBg(); delay(1500)
                val after = ctx.ram().let { it.second - it.first }
                val junk = withContext(Dispatchers.IO) { scanJunk(ctx) }
                msg = "Se cerraron procesos en segundo plano de $n apps. Memoria libre: ${fmt(before)} → ${fmt(after)}. " +
                    "Archivos basura encontrados: ${fmt(junk.sumOf { it.size })} (revísalos en LIMPIADOR; no se borró nada)."
                ctx.notify("Optimización completada", "Memoria libre: ${fmt(after)}")
                busy = false
            }
        }
        if (msg.isNotEmpty()) Cardx { Text(msg) }
    }
}

@Composable fun PermRow(name: String, ok: Boolean, onGrant: () -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(name, Modifier.weight(1f), fontSize = 14.sp)
        if (ok) Text("✓", color = Cyan, fontWeight = FontWeight.Bold) else TextButton(onGrant) { Text("Conceder") }
    }
}

@Composable fun SettingsScreen() {
    val ctx = LocalContext.current
    val ver = remember { ctx.packageManager.getPackageInfo(ctx.packageName, 0).versionName }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Title("Configuración")
        Cardx { Text("Tema: oscuro"); Text("Idioma: Español"); Text("HyperBoost versión $ver") }
        Cardx {
            Text("Información de la aplicación", fontWeight = FontWeight.Bold)
            Dim("Optimizador Android que solo usa APIs oficiales. No muestra mejoras inventadas.")
        }
        Cardx {
            Text("Política de privacidad", fontWeight = FontWeight.Bold)
            Dim("HyperBoost procesa todo localmente en tu teléfono. No envía información personal a ningún servidor. Nada se elimina sin tu confirmación.")
        }
        BigBtn("GESTIONAR PERMISOS") { ctx.appDetails(ctx.packageName) }
        BigBtn("CONTACTAR AL DESARROLLADOR") {
            ctx.open(Intent(Intent.ACTION_SENDTO, Uri.parse("mailto:contacto@hyperboost.app")).putExtra(Intent.EXTRA_SUBJECT, "HyperBoost"))
        }
    }
}
