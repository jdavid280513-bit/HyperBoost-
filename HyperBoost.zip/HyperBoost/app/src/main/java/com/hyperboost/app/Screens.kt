package com.hyperboost.app

import android.app.NotificationManager
import android.content.ContentUris
import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import android.provider.Settings
import android.util.Size
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.IntentSenderRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.graphics.drawable.toBitmap
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@Composable fun AppIcon(pkg: String) {
    val ctx = LocalContext.current
    val bm = remember(pkg) { runCatching { ctx.packageManager.getApplicationIcon(pkg).toBitmap(96, 96).asImageBitmap() }.getOrNull() }
    if (bm != null) Image(bm, null, Modifier.size(40.dp)) else Spacer(Modifier.size(40.dp))
}

@Composable fun AppRow(a: AppI, sub: String, trailing: @Composable RowScope.() -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
        AppIcon(a.pkg); Spacer(Modifier.width(10.dp))
        Column(Modifier.weight(1f)) { Text(a.label, maxLines = 1, overflow = TextOverflow.Ellipsis); Dim(sub) }
        trailing()
    }
}

@Composable fun UsageCard() {
    val ctx = LocalContext.current
    if (!ctx.hasUsage()) Cardx {
        Text("Falta el acceso de uso de apps", fontWeight = FontWeight.Bold)
        Dim("Sin este permiso Android no entrega qué apps usas ni cuánto.")
        BigBtn("CONCEDER ACCESO") { ctx.open(ctx.usageIntent()) }
    }
}

// ---------------- LIMPIADOR ----------------
@Composable fun Cleaner() {
    val ctx = LocalContext.current; val scope = rememberCoroutineScope()
    var items by remember { mutableStateOf<List<Junk>>(emptyList()) }
    var sel by remember { mutableStateOf<Set<String>>(emptySet()) }
    var busy by remember { mutableStateOf(false) }; var scanned by remember { mutableStateOf(false) }
    var confirm by remember { mutableStateOf(false) }; var done by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Title("Limpiador")
        if (!hasAllFiles()) Cardx {
            Text("Necesita acceso a todos los archivos"); BigBtn("CONCEDER ACCESO") { ctx.open(ctx.allFilesIntent()) }
        }
        Dim("Solo detecta temporales, logs, miniaturas, APK descargados y vacíos. Nunca fotos, videos ni documentos. Android 11+ no permite limpiar la caché de otras apps.")
        BigBtn(if (busy) "ANALIZANDO…" else "ANALIZAR") {
            if (!busy) scope.launch {
                busy = true; done = ""
                items = withContext(Dispatchers.IO) { scanJunk(ctx) }
                sel = items.map { it.file.path }.toSet(); busy = false; scanned = true
            }
        }
        if (done.isNotEmpty()) Text(done, color = Cyan)
        if (scanned) {
            Text("Se pueden liberar ${fmt(items.filter { it.file.path in sel }.sumOf { it.size })} (${items.size} archivos)", fontWeight = FontWeight.Bold)
            LazyColumn(Modifier.weight(1f)) {
                items(items, key = { it.file.path }) { j ->
                    val on = j.file.path in sel
                    Row(Modifier.fillMaxWidth().clickable { sel = if (on) sel - j.file.path else sel + j.file.path }.padding(vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(on, null); Spacer(Modifier.width(8.dp))
                        Column { Text(j.file.name, maxLines = 1, overflow = TextOverflow.Ellipsis); Dim("${j.kind} · ${fmt(j.size)} · ${j.file.parent}") }
                    }
                }
            }
            if (items.isNotEmpty()) BigBtn("ELIMINAR SELECCIONADOS") { if (sel.isNotEmpty()) confirm = true }
        }
    }
    if (confirm) AlertDialog(onDismissRequest = { confirm = false },
        title = { Text("¿Eliminar ${sel.size} archivos?") }, text = { Text("Esta acción no se puede deshacer.") },
        confirmButton = {
            TextButton({
                confirm = false
                val del = items.filter { it.file.path in sel }
                val freed = del.filter { it.file.delete() }.sumOf { it.size }
                items = items.filter { it.file.exists() }; sel = sel.filter { p -> items.any { it.file.path == p } }.toSet()
                done = "Liberado: ${fmt(freed)}"; ctx.notify("Limpieza completada", "Liberado: ${fmt(freed)}")
            }) { Text("Eliminar") }
        }, dismissButton = { TextButton({ confirm = false }) { Text("Cancelar") } })
}

// ---------------- RENDIMIENTO + BATERÍA ----------------
@Composable fun Perf() {
    val ctx = LocalContext.current; val scope = rememberCoroutineScope()
    var t by remember { mutableIntStateOf(0) }; var msg by remember { mutableStateOf("") }
    val (ru, rt) = remember(t) { ctx.ram() }
    val (bat, temp, chg) = remember(t) { ctx.battery() }
    val usage = remember(t) { ctx.usage(1) }
    val apps = remember { ctx.launchable() }
    val recent = apps.mapNotNull { a -> usage[a.pkg]?.let { a to it } }
        .filter { System.currentTimeMillis() - it.second.lastTimeUsed < 6 * 3600_000L }.sortedByDescending { it.second.lastTimeUsed }.take(12)
    val heavy = apps.mapNotNull { a -> usage[a.pkg]?.let { a to it } }.filter { it.second.totalTimeInForeground > 0 }
        .sortedByDescending { it.second.totalTimeInForeground }.take(6)
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Title("Rendimiento")
        Cardx {
            Text("Memoria RAM", fontWeight = FontWeight.Bold)
            LinearProgressIndicator(progress = { ru.toFloat() / rt }, Modifier.fillMaxWidth().height(8.dp).clip(RoundedCornerShape(4.dp)))
            Dim("En uso ${fmt(ru)} de ${fmt(rt)} · Disponible ${fmt(rt - ru)}")
        }
        UsageCard()
        BigBtn("CERRAR APPS EN SEGUNDO PLANO") {
            scope.launch {
                val b = rt - ru; val n = ctx.killBg(recent.map { it.first.pkg }.ifEmpty { apps.map { it.pkg } }); delay(1500)
                val a = ctx.ram().let { it.second - it.first }
                msg = "Memoria libre: ${fmt(b)} → ${fmt(a)} (cerrado de $n apps; Android puede reabrir algunas)"; t++
            }
        }
        if (msg.isNotEmpty()) Text(msg, color = Cyan)
        if (recent.isNotEmpty()) Cardx {
            Text("Usadas recientemente (probablemente en segundo plano)", fontWeight = FontWeight.Bold)
            recent.forEach { (a, u) -> AppRow(a, "Último uso: ${ago(u.lastTimeUsed).replace("hace 0 días", "hoy")}") {
                TextButton({ ctx.killBg(listOf(a.pkg)); t++ }) { Text("Cerrar") } } }
        }
        Cardx {
            Text("Batería: $bat%${if (chg) " (cargando)" else ""}", fontWeight = FontWeight.Bold)
            Dim(if (temp > 0) "Temperatura: $temp °C" else "Temperatura no disponible")
            if (heavy.isNotEmpty()) {
                Text("Apps con más tiempo en pantalla (24 h)", fontSize = 14.sp)
                heavy.forEach { (a, u) -> AppRow(a, "${u.totalTimeInForeground / 60000} min") {
                    TextButton({ ctx.appDetails(a.pkg) }) { Text("Ajustes") } } }
                Dim("Android no entrega el consumo real de batería por app; esto es tiempo de uso.")
            }
            BigBtn("MODO AHORRO DE ENERGÍA") { ctx.open(Intent(Settings.ACTION_BATTERY_SAVER_SETTINGS)) }
        }
        Cardx {
            Text("Consejos", fontWeight = FontWeight.Bold)
            Dim("• Baja el brillo o usa brillo automático.\n• Restringe la actividad en segundo plano de apps que no usas (Ajustes de la app → Batería).\n• Desinstala apps que no uses.\n• Reinicia el teléfono de vez en cuando.")
        }
    }
}

// ---------------- SEGURIDAD ----------------
data class Sec(val app: AppI, val dang: List<String>, val flags: List<String>)
val DANGER = setOf("CAMERA", "RECORD_AUDIO", "READ_SMS", "SEND_SMS", "READ_CONTACTS", "ACCESS_FINE_LOCATION", "READ_CALL_LOG",
    "SYSTEM_ALERT_WINDOW", "BIND_ACCESSIBILITY_SERVICE", "REQUEST_INSTALL_PACKAGES", "MANAGE_EXTERNAL_STORAGE", "READ_PHONE_STATE")

fun secScan(ctx: android.content.Context): List<Sec> = ctx.launchable().map { a ->
    val req = runCatching { ctx.packageManager.getPackageInfo(a.pkg, android.content.pm.PackageManager.GET_PERMISSIONS).requestedPermissions?.toList() }.getOrNull() ?: emptyList()
    val d = req.map { it.substringAfterLast('.') }.filter { it in DANGER }
    val src = runCatching { ctx.packageManager.getInstallSourceInfo(a.pkg).installingPackageName }.getOrNull()
    Sec(a, d, if (src == null) listOf("Instalada fuera de una tienda") else emptyList())
}.sortedByDescending { it.dang.size + it.flags.size * 2 }

@Composable fun Security() {
    val ctx = LocalContext.current
    val res by produceState<List<Sec>?>(null) { value = withContext(Dispatchers.IO) { secScan(ctx) } }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Title("Security Scanner")
        Dim("Analiza permisos y origen de instalación. No es un antivirus: no detecta malware ni afirma que haya virus.")
        val r = res
        if (r == null) CircularProgressIndicator() else {
            Cardx { Text("${r.size} apps analizadas", fontWeight = FontWeight.Bold) }
            Cardx {
                Text("Apps con permisos a revisar", fontWeight = FontWeight.Bold)
                r.filter { it.dang.size >= 3 || it.flags.isNotEmpty() }.take(10).forEach { s ->
                    AppRow(s.app, (s.flags + s.dang.joinToString(", ")).filter { it.isNotEmpty() }.joinToString(" · ")) {
                        TextButton({ ctx.appDetails(s.app.pkg) }) { Text("Permisos") } }
                }
            }
            val month = System.currentTimeMillis() - 30 * 86400000L
            Cardx {
                Text("Instaladas en los últimos 30 días", fontWeight = FontWeight.Bold)
                val rec = r.filter { it.app.installed > month }.sortedByDescending { it.app.installed }
                if (rec.isEmpty()) Dim("Ninguna")
                rec.forEach { AppRow(it.app, ago(it.app.installed)) {} }
            }
            Cardx { Text("Recomendaciones", fontWeight = FontWeight.Bold)
                Dim("• Instala solo desde tiendas oficiales.\n• Quita permisos que una app no necesita.\n• Ten especial cuidado con accesibilidad, superposición e instalación de apps.") }
        }
    }
}

// ---------------- HERRAMIENTAS ----------------
@Composable fun Tools(open: (String) -> Unit) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Title("Herramientas")
        listOf("freezer" to "APP FREEZER", "photos" to "FOTOS DUPLICADAS", "game" to "GAME BOOST", "info" to "INFORMACIÓN DEL DISPOSITIVO", "settings" to "CONFIGURACIÓN")
            .forEach { (k, n) -> BigBtn(n) { open(k) } }
    }
}

// ---------------- APP FREEZER ----------------
@Composable fun Freezer() {
    val ctx = LocalContext.current; var t by remember { mutableIntStateOf(0) }
    val usage = remember(t) { ctx.usage(30) }
    val all = remember(t) { ctx.apps() }
    val active = remember(t) { ctx.launchable() }
    val off = all.filter { !it.enabled && !it.system }
    val lastUsed = { a: AppI -> usage[a.pkg]?.lastTimeUsed ?: 0L }
    val rarely = active.filter { ctx.hasUsage() && System.currentTimeMillis() - lastUsed(it) > 14 * 86400000L }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Title("App Freezer")
        Dim("Android no permite que una app normal desactive otras apps. HyperBoost cierra sus procesos en segundo plano y te lleva a los ajustes del sistema para desactivarlas o restringirlas. Las apps del sistema no se muestran.")
        UsageCard()
        if (rarely.isNotEmpty()) Cardx {
            Text("Poco utilizadas (+14 días)", fontWeight = FontWeight.Bold)
            rarely.forEach { a -> FreezeRow(a, lastUsed(a)) { t++ } }
        }
        Cardx {
            Text("Apps instaladas (${active.size})", fontWeight = FontWeight.Bold)
            active.forEach { a -> FreezeRow(a, lastUsed(a)) { t++ } }
        }
        Cardx {
            Text("Desactivadas / congeladas", fontWeight = FontWeight.Bold)
            if (off.isEmpty()) Dim("Ninguna")
            off.forEach { a -> AppRow(a, "Desactivada") { TextButton({ ctx.appDetails(a.pkg) }) { Text("Restaurar") } } }
        }
    }
}
@Composable fun FreezeRow(a: AppI, last: Long, refresh: () -> Unit) {
    val ctx = LocalContext.current
    AppRow(a, "Último uso: ${ago(last)}") {
        TextButton({ ctx.killBg(listOf(a.pkg)); refresh() }) { Text("Cerrar") }
        TextButton({ ctx.appDetails(a.pkg) }) { Text("Congelar") }
    }
}

// ---------------- FOTOS DUPLICADAS ----------------
data class Img(val uri: Uri, val name: String, val size: Long)

fun findDup(ctx: android.content.Context): List<Pair<Boolean, List<Img>>> {
    val imgs = ArrayList<Img>()
    val base = MediaStore.Images.Media.EXTERNAL_CONTENT_URI
    ctx.contentResolver.query(base, arrayOf(MediaStore.Images.Media._ID, MediaStore.Images.Media.DISPLAY_NAME, MediaStore.Images.Media.SIZE),
        null, null, "${MediaStore.Images.Media.DATE_ADDED} DESC")?.use { c ->
        while (c.moveToNext() && imgs.size < 1500) imgs += Img(ContentUris.withAppendedId(base, c.getLong(0)), c.getString(1) ?: "", c.getLong(2))
    }
    val hs = imgs.map { i ->
        runCatching {
            val b = ctx.contentResolver.loadThumbnail(i.uri, Size(64, 64), null)
            val s = Bitmap.createScaledBitmap(b, 8, 8, true)
            val g = IntArray(64) { val p = s.getPixel(it % 8, it / 8); (((p shr 16) and 255) + ((p shr 8) and 255) + (p and 255)) / 3 }
            val avg = g.average(); var h = 0L
            g.forEachIndexed { k, v -> if (v > avg) h = h or (1L shl k) }; h
        }.getOrNull()
    }
    val used = BooleanArray(imgs.size); val out = ArrayList<Pair<Boolean, List<Img>>>()
    for (i in imgs.indices) {
        val hi = hs[i]; if (used[i] || hi == null) continue
        val g = mutableListOf(imgs[i])
        for (j in i + 1 until imgs.size) {
            val hj = hs[j]
            if (!used[j] && hj != null && java.lang.Long.bitCount(hi xor hj) <= 4) { used[j] = true; g += imgs[j] }
        }
        if (g.size > 1) { used[i] = true; out += (g.all { it.size == g[0].size }) to g }
    }
    return out
}

@Composable fun Thumb(u: Uri) {
    val ctx = LocalContext.current
    val bm by produceState<ImageBitmap?>(null, u) {
        value = withContext(Dispatchers.IO) { runCatching { ctx.contentResolver.loadThumbnail(u, Size(160, 160), null).asImageBitmap() }.getOrNull() }
    }
    Box(Modifier.size(64.dp).clip(RoundedCornerShape(10.dp)).background(Color(0xFF222222))) {
        bm?.let { Image(it, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop) }
    }
}

@Composable fun Photos() {
    val ctx = LocalContext.current; val scope = rememberCoroutineScope()
    var groups by remember { mutableStateOf<List<Pair<Boolean, List<Img>>>>(emptyList()) }
    var sel by remember { mutableStateOf<Set<Uri>>(emptySet()) }
    var busy by remember { mutableStateOf(false) }; var scanned by remember { mutableStateOf(false) }
    val del = rememberLauncherForActivityResult(ActivityResultContracts.StartIntentSenderForResult()) {
        if (it.resultCode == android.app.Activity.RESULT_OK) {
            ctx.notify("Fotos eliminadas", "${sel.size} fotos"); groups = groups.map { g -> g.first to g.second.filter { i -> i.uri !in sel } }.filter { it.second.size > 1 }; sel = emptySet()
        }
    }
    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Title("Fotos duplicadas")
        if (!ctx.hasPhotos()) Dim("Falta el permiso de fotos: concédelo en Inicio o en Configuración → Gestionar permisos.")
        else BigBtn(if (busy) "ANALIZANDO…" else "ANALIZAR GALERÍA") {
            if (!busy) scope.launch {
                busy = true; groups = withContext(Dispatchers.IO) { findDup(ctx) }
                sel = groups.flatMap { it.second.drop(1) }.map { it.uri }.toSet(); busy = false; scanned = true
            }
        }
        if (scanned) {
            val sz = groups.flatMap { it.second }.filter { it.uri in sel }.sumOf { it.size }
            Text(if (groups.isEmpty()) "No se encontraron duplicadas" else "${groups.size} grupos · seleccionadas ocupan ${fmt(sz)}", fontWeight = FontWeight.Bold)
            LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                items(groups) { (exact, g) ->
                    Cardx {
                        Dim(if (exact) "Idénticas (mismo tamaño y aspecto)" else "Visualmente similares")
                        g.forEach { i ->
                            Row(Modifier.fillMaxWidth().clickable { sel = if (i.uri in sel) sel - i.uri else sel + i.uri }, verticalAlignment = Alignment.CenterVertically) {
                                Checkbox(i.uri in sel, null); Thumb(i.uri); Spacer(Modifier.width(10.dp))
                                Column { Text(i.name, maxLines = 1, overflow = TextOverflow.Ellipsis); Dim(fmt(i.size)) }
                            }
                        }
                    }
                }
            }
            if (sel.isNotEmpty()) BigBtn("ELIMINAR SELECCIONADAS") {
                del.launch(IntentSenderRequest.Builder(MediaStore.createDeleteRequest(ctx.contentResolver, sel.toList()).intentSender).build())
            }
        }
    }
}

// ---------------- GAME BOOST ----------------
@Composable fun Game() {
    val ctx = LocalContext.current
    val prefs = remember { ctx.getSharedPreferences("hb", 0) }
    var favs by remember { mutableStateOf(prefs.getStringSet("favs", emptySet())!!.toSet()) }
    val nm = ctx.getSystemService(NotificationManager::class.java)
    var dnd by remember { mutableStateOf(nm.currentInterruptionFilter != NotificationManager.INTERRUPTION_FILTER_ALL) }
    val all = remember { ctx.launchable() }
    val games = remember { all.filter { it.game }.ifEmpty { all } }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Title("Game Boost")
        Dim("Libera memoria cerrando procesos en segundo plano y silencia notificaciones. No modifica FPS ni el procesador.")
        Cardx {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("No molestar", Modifier.weight(1f))
                Switch(dnd, { on ->
                    if (!ctx.hasDnd()) ctx.open(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS))
                    else { nm.setInterruptionFilter(if (on) NotificationManager.INTERRUPTION_FILTER_PRIORITY else NotificationManager.INTERRUPTION_FILTER_ALL); dnd = on }
                })
            }
            BigBtn("AJUSTES DE RENDIMIENTO") { ctx.open(Intent(Settings.ACTION_DISPLAY_SETTINGS)) }
        }
        Cardx {
            Text(if (all.none { it.game }) "Apps (no se detectaron juegos por categoría)" else "Juegos instalados", fontWeight = FontWeight.Bold)
            games.sortedByDescending { it.pkg in favs }.forEach { a ->
                AppRow(a, if (a.pkg in favs) "Favorito" else "") {
                    IconButton({
                        favs = if (a.pkg in favs) favs - a.pkg else favs + a.pkg
                        prefs.edit().putStringSet("favs", favs).apply()
                    }) { Icon(Icons.Filled.Star, "Favorito", tint = if (a.pkg in favs) Cyan else Color.Gray) }
                    TextButton({
                        ctx.killBg(all.map { it.pkg }.filter { it != a.pkg })
                        ctx.packageManager.getLaunchIntentForPackage(a.pkg)?.let { ctx.open(it) }
                    }) { Text("Jugar") }
                }
            }
        }
        Cardx { Text("Consejos", fontWeight = FontWeight.Bold)
            Dim("• Activa el modo de rendimiento del fabricante si existe.\n• Evita jugar cargando si el teléfono se calienta.\n• Cierra apps pesadas antes de jugar.") }
    }
}

// ---------------- INFO ----------------
@Composable fun Info() {
    val ctx = LocalContext.current
    val dm = ctx.resources.displayMetrics
    val (_, rt) = ctx.ram(); val (su, st) = storage(); val (bat, _, _) = ctx.battery()
    val hz = runCatching { ctx.display?.refreshRate }.getOrNull()
    val rows = listOf(
        "Modelo" to Build.MODEL, "Marca" to Build.MANUFACTURER.replaceFirstChar { it.uppercase() },
        "Android" to "${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})",
        "RAM" to fmt(rt), "Almacenamiento total" to fmt(st), "Almacenamiento disponible" to fmt(st - su),
        "Batería" to "$bat%",
        "Procesador" to (if (Build.VERSION.SDK_INT >= 31 && Build.SOC_MODEL.isNotBlank() && Build.SOC_MODEL != "unknown") Build.SOC_MODEL else Build.HARDWARE) + " · ${Runtime.getRuntime().availableProcessors()} núcleos",
        "Pantalla" to "${dm.widthPixels}×${dm.heightPixels} · ${dm.densityDpi} dpi" + (hz?.let { " · ${it.toInt()} Hz" } ?: "")
    )
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Title("Información del dispositivo")
        Cardx { rows.forEach { (k, v) -> Row { Text(k, Modifier.weight(1f), color = Color.Gray); Text(v, Modifier.weight(1.4f)) } } }
    }
}
